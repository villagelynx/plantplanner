Place licensed plant photos in this folder.

For the top 20 popular plants, you can now drop files into:

`images/popular/`

Using these filenames:
- `lavender.jpg`
- `hydrangea.jpg`
- `rosemary.jpg`
- `coneflower.jpg`
- `hosta.jpg`
- `japanese-maple.jpg`
- `snake-plant.jpg`
- `monstera.jpg`
- `pothos.jpg`
- `peace-lily.jpg`
- `boston-fern.jpg`
- `petunia.jpg`
- `marigold.jpg`
- `zinnia.jpg`
- `sunflower.jpg`
- `boxwood.jpg`
- `dogwood.jpg`
- `blueberry.jpg`
- `tomato.jpg`
- `aloe-vera.jpg`

If those files exist, the app will use them automatically for those popular plants without any extra edits in `app.js`.

You can point any plant at a real photo in `app.js` with one of these fields:

```js
plant("Lavender", "Lavandula angustifolia", {
  imagePath: "lavender.jpg"
})
```

```js
plant("Lavender", "Lavandula angustifolia", {
  image: "./images/lavender.jpg"
})
```

```js
plant("Lavender", "Lavandula angustifolia", {
  imageUrl: "https://example.com/lavender.jpg"
})
```

Supported fields:
- `image`
- `imageUrl`
- `photo`
- `photoUrl`
- `imagePath`
- `photoPath`
- `imageFile`
- `photoFile`

If no real photo is provided, the app automatically falls back to the built-in generated plant illustration.
